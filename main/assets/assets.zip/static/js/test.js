let a = "";
console.log(a.length, typeof a)